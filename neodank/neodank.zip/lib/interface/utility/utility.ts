export type Colors = {
  [name: string]: number;
};
