import type { AkairoOptions } from 'discord-akairo';

export const akairoConfig: AkairoOptions = {
  ownerID: '605419747361947649',
};
