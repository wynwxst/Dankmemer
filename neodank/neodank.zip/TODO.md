# To Do's

Just a list of planned features basically for event and currency commands. 

## Currency

- [ ] **Sale Item**
- [x] **Give, Gift Commands**
- [ ] **Prestige**
- [ ] **Quests**

## Memers Crib

- [ ] **Event Commands**
- [x] **Donation System**
- [ ] **Giveaway Commands**

## Back-End

- [x] **Item Checks**
- [x] **Fix Bot Latency**
